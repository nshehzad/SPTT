# aspnetcoresaml

Sample project to go with this blog post on Authentication in ASP.NET Core with SAML v2

https://cmatskas.com/asp-net-core-saml-authentication-with-azure-ad/
